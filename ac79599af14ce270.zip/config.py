settings = {
    'token': 'ODc1NDUwOTMwNzY4NzkzNjQw.YRVtNg.j0QyaDe02SbtVkEQjQ3mKYLaRek',
    'bot': 'KatyaBot',
    'id': 875450930768793640,
    'prefix': '.'
}