import discord
import asyncio
import os
import sys
import random
import datetime

from discord.ext import commands
from config import settings
from discord.ext.commands import Bot

bot = commands.Bot(command_prefix = settings['prefix'])
bot.remove_command('help')

@bot.event
async def on_ready():
    print( "Бот запустился!" )

    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="Made in deHander.ru"))


@bot.command(name = "say")
async def _say(ctx, *, arg = None):
    embed = discord.Embed(
        description = f"{arg}")
    await ctx.send(embed = embed)

bot.run(settings['token']) 